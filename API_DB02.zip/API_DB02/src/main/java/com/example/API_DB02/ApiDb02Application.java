package com.example.API_DB02;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiDb02Application {

	public static void main(String[] args) {
		SpringApplication.run(ApiDb02Application.class, args);
	}

}
