package com.example.API_DB02;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiDb02ApplicationTests {

	@Test
	void contextLoads() {
	}

}
